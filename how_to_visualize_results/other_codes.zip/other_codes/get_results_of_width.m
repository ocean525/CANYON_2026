
clear;clc
suffix={'W1';'W1_5';'W2';'W2_5';'W3';'W5';'W7';'W10';'W20'};
wide=[0.5e3 1.5e3/2 1e3 2.5e3/2 1.5e3 2.5e3 7e3/2 5e3 10e3];

rho0=999.8;
right_boundary=350;%等值线的取法
left_boundary=310e3;%等值线的取法
middle_y=49990;

for su=1:9
load(['D:\CANYON\Fourth phase\ALLCASES\grid_',suffix{su},'.mat'])
load(['D:\CANYON\Fourth phase\ALLCASES\Energy_density_',suffix{su},'.mat'])
load(['D:\CANYON\Fourth phase\ALLCASES\Con_',suffix{su},'.mat'])
load(['D:\CANYON\Fourth phase\ALLCASES\Flux_ebc_',suffix{su},'.mat'])
load(['D:\CANYON\Fourth phase\ALLCASES\Flux_pbc_',suffix{su},'.mat'])
%load(['D:\CANYON\Fourth phase\ALLCASES\KLeps_',suffix{su},'.mat'])

half_wide=wide(su);

%区域 in
XC=XC';
YC=YC';
clear x11 y11 x22 y22 x33 y33 y44
C = contourc(XC(:,1), YC(1,:), Depth, [right_boundary right_boundary]);    % 提取 z=350m 等值线数据
x1=C(1,2:end);
y1=C(2,2:end);
x11=x1(y1>middle_y-half_wide&y1<middle_y+half_wide);
y11=y1(y1>middle_y-half_wide&y1<middle_y+half_wide);
% 2
y2=20e3:1e2:70e3;
x2=y2;
x2(:)=left_boundary;

x22=x2(y2>min(y11)&y2<max(y11));
y22=y2(y2>min(y11)&y2<max(y11));

% 3 4
x3=300e3:1e2:500e3;
x33=x3(x3>=x2(1)&x3<=x11(1));
y33(1:length(x33))=middle_y-half_wide;
y44(1:length(x33))=middle_y+half_wide;

clear line xp yp
line(1,:)=[x11,flip(x33),x22,x33];
line(2,:)=[y11,flip(y33),y22,y44];

xp=line(1,:);
yp=line(2,:);
in = inpolygon(XC',YC', xp, yp);

%KLeps(KLeps==0)=nan;
%KL=KLeps*999.8*10;
%KL=sq(sum(KL,1,'omitnan'));
%KL_L(su)=sum(KL.*DXG.*DYG.*in,'all');

Earea=(sq(Ebc(49,:,:)-Ebc(1,:,:))*rho0)/43200;

Fu=sq(mean(uEbc(1:48,:,:)+uPbc(1:48,:,:),1));
Fv=sq(mean(vEbc(1:48,:,:)+vPbc(1:48,:,:),1));
fx=(Fu(:,2:end)-Fu(:,1:end-1))./DXG(:,1:end-1);
fy=(Fv(2:end,:)-Fv(1:end-1,:))./DYG(1:end-1,:);
DIV = fx(1:end-1,:)+fy(:,1:end-1);
DIV(440,900)=0;
DIV=DIV*999.8;

CON=sq(mean(Conv(1:48,:,:),1))*rho0;

DISS=-Earea-DIV+CON;


Eareabc_L(su)=sum(Earea.*DXG.*DYG.*in,'all');
DIVbc_L(su)=sum(DIV.*DXG.*DYG.*in,'all');
CONbc_L(su)=sum(CON.*DXG.*DYG.*in,'all');
DISSbc_L(su)=sum(DISS.*DXG.*DYG.*in,'all');

% 还需要计算一下体积
total_volume_L(su)=sum(Depth.*in.*DXG.*DYG,'all');
mean_density=1.0001e+03;

BC_rate_L(su)=DISSbc_L(su)/total_volume_L(su)/mean_density;
%BC_rate_KL(su)=KL_L(su)/total_volume_L(su)/mean_density;

% y0=215:220;
% DISSbc_L=sum(DISS(y0,:).*DXG(y0,:).*in(y0,:),'all');
% total_area_L=sum(Depth(y0,:).*in(y0,:).*DXG(y0,:),'all');
% BC_rate_L=DISSbc_L/total_area_L/1.0001e+03


disp(su)
end

W=[1 1.5 2 2.5 3 5 7 10 20];
save('width_results.mat','W','BC_rate_L','DISSbc_L','total_volume_L','Eareabc_L','DIVbc_L','CONbc_L')%,'BC_rate_KL'

W=wide*2/1e3
save('width_results.mat','W','BC_rate_L','BC_rate_KL','DISSbc_L','total_volume_L','Eareabc_L','DIVbc_L','CONbc_L')

W=[1 1.5 2 2.5 3 5 7 20];
save('width_results_kl.mat','W','BC_rate_L','BC_rate_KL','DISSbc_L','total_volume_L','Eareabc_L','DIVbc_L','CONbc_L')%,'BC_rate_KL'


%% 绘图
load 'width_results_high.mat'


figure
h1=plot(W/60, BC_rate_L, '-o', ...
    'LineWidth', 1.5, ...
    'Color', 'b', ...
    'MarkerFaceColor', 'b')
set(gcf,'Color','w')

hold on
C=plot(W(8)/60, BC_rate_L(8), 'p', ...
    'LineWidth', 0.5, ...
    'Color', 'k', ...
    'MarkerFaceColor', 'k','MarkerSize',15)

xlabel('$W / \lambda$','Interpreter','latex','FontSize',16)
ylabel('$\varepsilon\ (\mathrm{m^2\,s^{-3}})$','Interpreter','latex','FontSize',16)

xlim([0 0.35])
ylim([0 6e-8])


hold on
A = xline(0.425, '--', 'LineWidth', 1.5);

xlim([0.1 1.1])
xticks([0,0.25,0.33,0.383,0.425,0.5,0.75,1])


%% final
load('width_results_final.mat')
figure
h1=plot(W/60,BC_rate_L,'-o', ...
    'LineWidth', 1.5, ...
    'Color', 'b', ...
    'MarkerFaceColor', 'b')
set(gcf,'Color','w')

xlabel('$W / \lambda$','Interpreter','latex','FontSize',16)
ylabel('$\varepsilon\ (\mathrm{W\,kg^{-1}})$','Interpreter','latex','FontSize',16)
ylabel('$\varepsilon\ (\mathrm{m^2\,s^{-3}})$','Interpreter','latex','FontSize',16)

hold on
C=plot(W(8)/60, BC_rate_L(8), 'p', ...
    'LineWidth', 0.5, ...
    'Color', 'k', ...
    'MarkerFaceColor', 'k','MarkerSize',15)

set(gca,'Layer','top','XMinorGrid','off','YMinorTick','off','TickDir','in')
box on

set(findall(gcf,'-property','FontSize'),'FontSize',16);

xticks([0,0.033,0.05,0.083,0.167,0.33])
ylim([0 6e-8])

x1 = 0.0333;
x2 = 0.04167;

yl = ylim;     % 自动使用当前图的 Y 范围

A=patch([x1 x2 x2 x1], [yl(1) yl(1) yl(2) yl(2)], ...
      [0.3 0.3 0.3], ...       % 灰色
      'EdgeColor','none', ...  % 无边框
      'FaceAlpha',0.3);        % 透明度

ax1 = gca;
ax1.Box = 'off';

ax2 = axes('Position', ax1.Position, ...
           'XAxisLocation','top', ...
           'Color','none');
ax2.YAxis.Visible = 'off';

linkaxes([ax1 ax2],'x')
ax2.XLim = ax1.XLim;
ax2.XTick = ax1.XTick(2:end);
ax2.XTickLabel = round(ax1.XTick(2:end) * 60);
xlabel(ax2, 'W')

xlim([0 0.35])
xr = xlim;     % [xmin xmax]
yr = ylim;     % [ymin ymax]
hold on
%C1=plot([xr(2) xr(2)], [yr(1)-20 yr(2)], 'k-', 'LineWidth', 0.5);

legend([h1, C], {'Inferred Dissipation', 'Control'})
set(findall(gcf,'-property','FontSize'),'FontSize',20);
set(findall(gcf,'-property','FontWeight'),'FontWeight','bold');

%%  
% high resolution
% load 'width_results_high.mat'
% 
% plot(W/60,BC_rate_L,'--*', ...
%     'LineWidth', 1.5, ...
%     'Color', 'r', ...
%     'MarkerFaceColor', 'r')
% set(gcf,'Color','w')
% xlabel('Canyon length / Wave length')
% 
% xlabel('$W / \lambda$','Interpreter','latex','FontSize',16)
% ylabel('$\varepsilon\ (\mathrm{W\,kg^{-1}})$','Interpreter','latex','FontSize',16)
% ylabel('$\varepsilon\ (\mathrm{m^2\,s^{-3}})$','Interpreter','latex','FontSize',16)
% 
% Lb / Lw
% hold on
% 
% plot(W/60,BC_rate_KL,'--*', ...
%     'LineWidth', 1.5, ...
%     'Color', 'b', ...
%     'MarkerFaceColor', 'b')
% 
% 
% set(gca,'Layer','top','XMinorGrid','off','YMinorTick','off','TickDir','in')
% box on
% ylim([0 6e-8])
% 
% set(findall(gcf,'-property','FontSize'),'FontSize',16);
% 
% legend('Inferred Dissipation','KL10 Dissipation','Higher resolution','Higher resolution')
% 
% xlim([0 0.55])

%% 近临界地形的比率  suffix={'L15';'L20';'L22_5';'L25';'L275';'W10';'L40';'L60';'L90';'L120'};
clear;clc
suffix={'W1_high';'W5';'W7_5';'W10';'W15';'W20';'W30'};
wide=[0.5e3 2.5e3 7.5e3/2 5e3 7.5e3 10e3 15e3];
rho0=999.8;
right_boundary=350;%等值线的取法
left_boundary=310e3;%等值线的取法
middle_y=49900;



w=2*pi/43200
 N2=4.7808e-6
 k=(pi/2000)*sqrt(w^2/(N2-w^2))
 l=2*pi/k
 m=pi/2000

 critical_slope=k/m%0.0667


for su=1:7
load(['D:\CANYON\Third phase\ALL_CASES\grid_',suffix{su},'.mat'])
half_wide=wide(su);
%区域 in
XC=XC';
YC=YC';
clear x11 y11 x22 y22 x33 y33 y44
C = contourc(XC(:,1), YC(1,:), Depth, [right_boundary right_boundary]);    % 提取 z=350m 等值线数据
x1=C(1,2:end);
y1=C(2,2:end);
x11=x1(y1>middle_y-half_wide&y1<middle_y+half_wide);
y11=y1(y1>middle_y-half_wide&y1<middle_y+half_wide);
% 2
y2=20e3:1e2:70e3;
x2=y2;
x2(:)=left_boundary;

x22=x2(y2>min(y11)&y2<max(y11));
y22=y2(y2>min(y11)&y2<max(y11));

% 3 4
x3=300e3:1e2:500e3;
x33=x3(x3>=x2(1)&x3<=x11(1));
y33(1:length(x33))=middle_y-half_wide;
y44(1:length(x33))=middle_y+half_wide;

clear line xp yp
line(1,:)=[x11,flip(x33),x22,x33];
line(2,:)=[y11,flip(y33),y22,y44];

xp=line(1,:);
yp=line(2,:);
in = inpolygon(XC',YC', xp, yp);
 
% 三维的梯度
D=-Depth;
dx=(D(:,2:end)-D(:,1:end-1))./DXG(:,1:end-1);
dy=(D(2:end,:)-D(1:end-1,:))./DYG(1:end-1,:);
%grad_Depth = sqrt(dx(1:end-1,:).^2 + dy(:,1:end-1).^2);
%grad_Depth = dx;
grad_Depth = dy;
if su==1
grad_Depth (245,1520)=0;
else
grad_Depth (264,1260)=0;
end
critical_mask = abs(grad_Depth - critical_slope) < 0.15 * critical_slope;  % 可调容差
%critical_mask = (grad_Depth - critical_slope) > 0.15 * critical_slope &  (grad_Depth - critical_slope) >0;  % 可调容差
ratio(su) = sum(critical_mask.*in,'all') / sum(in,'all') ;
disp(su)
end

%contourf(XC,YC,grad_Depth.*in)
% 
% subcritical_mask = slope <  critical_slope;
% supercritical_mask = slope >  critical_slope;
% critical_mask = abs(grad_Depth - critical_slope) < 0.20 * critical_slope;  % 可调容差
% ratio = sum(critical_mask.*in,'all') / sum(in,'all') ;


figure
contourf(XC,YC,grad_Depth'.*in')
% 
figure
contourf(XC,YC,critical_mask'.*in')
% 


figure
plot(W,BC_rate_L/max(BC_rate_L))
hold on

plot(W,ratio/max(ratio))%找到了最匹配的值,15~25% 的x方向梯度占比。这个数越大，耗散能力就越强
% 而宽度的情况，单纯的宽度就是线性的了，就是简单的越窄越强--虽然入射的能力减小了。


%%
figure
loglog(BC_rate_L, ratio, 'ko', 'MarkerFaceColor','k');
hold on
xlim([min(BC_rate_L)*0.8, max(BC_rate_L)*1.2])
ylim([min(ratio)*0.8, max(ratio)*1.2])
% 取得当前坐标轴范围
xl = xlim;
yl = ylim;
% 计算对角线端点：左下角和右上角
x1 = xl(1);
x2 = xl(2);
y1 = yl(1);
y2 = yl(2);
% 在对数坐标下绘制穿过坐标框的45°线
loglog([x1 x2], [y1 y2], 'r--', 'LineWidth', 1.2)

axis square
xlabel('Near-critical area ratio')
ylabel('Mean dissipation rate')
grid on


%%
x = BC_rate_L ./ max(BC_rate_L);
y = ratio ./ max(ratio);
%y = W ./ max(W);

figure
scatter(x, y, 'filled')
hold on
plot([0 1], [1 0], 'r--', 'LineWidth', 1.2)
axis([0 1 0 1])
axis square
xlabel('Normalized near-critical area ratio')
ylabel('Normalized mean dissipation rate')
grid on

r = sum((x - mean(x)) .* (y - mean(y))) / sqrt(sum((x - mean(x)).^2) * sum((y - mean(y)).^2));
disp(r)

%极强正相关

