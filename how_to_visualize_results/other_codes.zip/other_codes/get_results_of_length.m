clear;clc
suffix={'L15';'L20';'L22';'L23';'L24';'L255';'W10';'L45';'L60'};
half_wide=5e3;
rho0=999.8;
right_boundary=350;
left_boundary=310e3;


middle_y=49990;

for su=1:9
load(['D:\CANYON\Fourth phase\ALLCASES\grid_',suffix{su},'.mat'])
load(['D:\CANYON\Fourth phase\ALLCASES\Energy_density_',suffix{su},'.mat'])
load(['D:\CANYON\Fourth phase\ALLCASES\Con_',suffix{su},'.mat'])
load(['D:\CANYON\Fourth phase\ALLCASES\Flux_ebc_',suffix{su},'.mat'])
load(['D:\CANYON\Fourth phase\ALLCASES\Flux_pbc_',suffix{su},'.mat'])


XC=XC';
YC=YC';
clear x11 y11 x22 y22 x33 y33 y44
C = contourc(XC(:,1), YC(1,:), Depth, [right_boundary right_boundary]);    
x1=C(1,2:end);
y1=C(2,2:end);
x11=x1(y1>middle_y-half_wide&y1<middle_y+half_wide);
y11=y1(y1>middle_y-half_wide&y1<middle_y+half_wide);
% 2
y2=20e3:1e2:70e3;
x2=y2;
x2(:)=left_boundary;

x22=x2(y2>min(y11)&y2<max(y11));
y22=y2(y2>min(y11)&y2<max(y11));

% 3 4
x3=300e3:1e2:500e3;
x33=x3(x3>=x2(1)&x3<=x11(1));
y33(1:length(x33))=middle_y-half_wide;
y44(1:length(x33))=middle_y+half_wide;

clear line xp yp
line(1,:)=[x11,flip(x33),x22,x33];
line(2,:)=[y11,flip(y33),y22,y44];

xp=line(1,:);
yp=line(2,:);
in = inpolygon(XC',YC', xp, yp);


Earea=(sq(Ebc(49,:,:)-Ebc(1,:,:))*rho0)/43200;

Fu=sq(mean(uEbc(1:48,:,:)+uPbc(1:48,:,:),1));
Fv=sq(mean(vEbc(1:48,:,:)+vPbc(1:48,:,:),1));
fx=(Fu(:,2:end)-Fu(:,1:end-1))./DXG(:,1:end-1);
fy=(Fv(2:end,:)-Fv(1:end-1,:))./DYG(1:end-1,:);
DIV = fx(1:end-1,:)+fy(:,1:end-1);
DIV(440,900)=0;
DIV=DIV*999.8;

CON=sq(mean(Conv(1:48,:,:),1))*rho0;

DISS=-Earea-DIV+CON;


Eareabc_L(su)=sum(Earea.*DXG.*DYG.*in,'all');%
DIVbc_L(su)=sum(DIV.*DXG.*DYG.*in,'all');%
CONbc_L(su)=sum(CON.*DXG.*DYG.*in,'all');%
DISSbc_L(su)=sum(DISS.*DXG.*DYG.*in,'all');%

total_volume_L(su)=sum(Depth.*in.*DXG.*DYG,'all');
mean_density=1.0001e+03;

BC_rate_L(su)=DISSbc_L(su)/total_volume_L(su)/mean_density;%

disp(su)
end


%L=[15 20 22 23 24 25.5 30 45 60];
%save('length_results.mat','L','BC_rate_L','DISSbc_L','total_volume_L','Eareabc_L','DIVbc_L','CONbc_L')%'BC_rate_KL',

