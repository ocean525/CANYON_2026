clear;clc
suffix={'W10';'015';'010'};
half_wide=5e3;
rho0=999.8;
right_boundary=350;
left_boundary=310e3;
middle_y=50e3;
addpath 'D:\CANYON\Fourth phase\ALLCASES'
addpath 'D:\CANYON\Fourth phase\ALLCASES\back_slope_015'
addpath 'D:\CANYON\Fourth phase\ALLCASES\back_slope_010'

for su=1:3
load(['grid_',suffix{su},'.mat'])
load(['Energy_density_',suffix{su},'.mat'])
load(['Con_',suffix{su},'.mat'])
load(['Flux_ebc_',suffix{su},'.mat'])
load(['Flux_pbc_',suffix{su},'.mat'])
load(['KLeps_',suffix{su},'.mat'])
load(['Energy_density_bt_',suffix{su},'.mat'])
load(['Flux_ebt_',suffix{su},'.mat'])
load(['Flux_pbt_',suffix{su},'.mat'])


%
XC=XC';
YC=YC';
clear x11 y11 x22 y22 x33 y33 y44
C = contourc(XC(:,1), YC(1,:), Depth, [right_boundary right_boundary]);  
x1=C(1,2:end);
y1=C(2,2:end);
x11=x1(y1>middle_y-half_wide&y1<middle_y+half_wide);
y11=y1(y1>middle_y-half_wide&y1<middle_y+half_wide);
% 2
y2=20e3:1e2:70e3;
x2=y2;
x2(:)=left_boundary;

x22=x2(y2>min(y11)&y2<max(y11));
y22=y2(y2>min(y11)&y2<max(y11));

% 3 4
x3=300e3:1e2:500e3;
x33=x3(x3>=x2(1)&x3<=x11(1));
y33(1:length(x33))=middle_y-half_wide;
y44(1:length(x33))=middle_y+half_wide;

clear line xp yp
line(1,:)=[x11,flip(x33),x22,x33];
line(2,:)=[y11,flip(y33),y22,y44];

xp=line(1,:);
yp=line(2,:);
in = inpolygon(XC',YC', xp, yp);


% KL dissipation rate, not used
KLeps(KLeps==0)=nan;
KL=KLeps*999.8*10;
KL=sq(sum(KL,1,'omitnan'));
KL_L(su)=sum(KL.*DXG.*DYG.*in,'all');
total_volume_S(su)=sum(Depth.*in.*DXG.*DYG,'all');
mean_density=1.0001e+03;
BC_rate_KL(su)=KL_L(su)/total_volume_S(su)/mean_density;




%% 
Earea=(sq(Ebc(49,:,:)-Ebc(1,:,:))*rho0)/(43200);
Fu=sq(mean(uEbc(1:48,:,:)+uPbc(1:48,:,:),1))*rho0;
Fv=sq(mean(vEbc(1:48,:,:)+vPbc(1:48,:,:),1))*rho0;
fx=(Fu(:,2:end)-Fu(:,1:end-1))./DXG(:,1:end-1);
fy=(Fv(2:end,:)-Fv(1:end-1,:))./DYG(1:end-1,:);
DIV = fx(1:end-1,:)+fy(:,1:end-1);
DIV(440,900)=0;
CON=sq(mean(Conv(1:48,:,:),1))*rho0;
DISS=-Earea-DIV+CON;


Eareabt=(sq(Ebt(49,:,:)-Ebt(1,:,:))*rho0)/(43200);
Fu=sq(mean(uEbt(1:48,:,:)+uPbt(1:48,:,:),1))*rho0;
Fv=sq(mean(vEbt(1:48,:,:)+vPbt(1:48,:,:),1))*rho0;
fx=(Fu(:,2:end)-Fu(:,1:end-1))./DXG(:,1:end-1);
fy=(Fv(2:end,:)-Fv(1:end-1,:))./DYG(1:end-1,:);
DIVbt = fx(1:end-1,:)+fy(:,1:end-1);
DIVbt(440,900)=0;
CON=sq(mean(Conv(1:48,:,:),1))*rho0;
DISSbt=-Eareabt-DIVbt-CON;

%% 
Eareabc_c=sum(Earea.*DXG.*DYG.*in,'all')/1e6 ;  
DIVbc_c=sum(DIV.*DXG.*DYG.*in,'all')/1e6  ;
CONbc_c=sum(CON.*DXG.*DYG.*in,'all')/1e6  ;
E_BT_c=sum(Eareabt.*DXG.*DYG.*in,'all')/1e6  ;
DIV_BT_c=sum(DIVbt.*DXG.*DYG.*in,'all')/1e6  ;
DISSbc_c=sum(DISS.*DXG.*DYG.*in,'all')/1e6  ;
DISS_BT_c=sum(DISSbt.*DXG.*DYG.*in,'all')/1e6  ;

load in_whole_90.mat

Eareabc=sum(Earea.*DXG.*DYG.*in_whole,'all')/1e6  ;
DIVbc=sum(DIV.*DXG.*DYG.*in_whole,'all')/1e6   ;
CONbc=sum(CON.*DXG.*DYG.*in_whole,'all')/1e6  ;
DISSbc=sum(DISS.*DXG.*DYG.*in_whole,'all')/1e6;
E_BT=sum(Eareabt.*DXG.*DYG.*in_whole,'all')/1e6  ;
DIV_BT=sum(DIVbt.*DXG.*DYG.*in_whole,'all')/1e6  ;
DISS_BT=sum(DISSbt.*DXG.*DYG.*in_whole,'all')/1e6  ;


% outer canyon
CONbc_outer=sum(CON.*DXG.*DYG.*in_whole.*(~in),'all')/1e6  ;

%
load line.mat

Fu=sq(mean(uEbc(1:48,:,:)+uPbc(1:48,:,:),1))*rho0;
Fv=sq(mean(vEbc(1:48,:,:)+vPbc(1:48,:,:),1))*rho0;

Fu_left(su)=sum(Fu(yd:yu,xl).*DYG(yd:yu,xl));
Fu_right(su)=sum(Fu(yd:yu,xr).*DYG(yd:yu,xr));
Fv_down(su)=sum(Fv(yd,xl:xr).*DXG(yd,xl:xr));
Fv_up(su)=sum(Fv(yu,xl:xr).*DXG(yu,xl:xr));

F_line(su)=-Fu_left(su)+Fu_right(su)-Fv_down(su)+Fv_up(su);
E_div(su) = sum(DIV.*DXG.*DYG.*in_whole,'all');



%% OUTER
BC_input_o(su)=DIVbc;
BC_to_BT(su)=CONbc-CONbc_c;
BC_diss_o(su)=DISSbc-DISSbc_c;
BC_re_o(su)=Eareabc-Eareabc_c;

BT_input_o(su)=DIV_BT;
BT_diss_o(su)=DISS_BT-DISS_BT_c;
BT_re_o(su)=E_BT-E_BT_c;


%% INNER
BC_input_c(su)=DIVbc_c;
BT_input_c(su)=DIV_BT_c;
BT_to_BC(su)=CONbc_c;
BT_re_c(su)=E_BT_c;
BT_diss_c(su)=DISS_BT_c;
BC_re_c(su)=Eareabc_c;
BC_diss_c(su)=DISSbc_c;

% key volume average BC energy dissipation rate
BC_rate_S(su)=BC_diss_c(su)*1e6/total_volume_S(su)/mean_density;


%disp('---------------------')
disp(su)
end



E = table( ...
	    BC_rate_S(:),total_volume_S(:), ...          % KL_L 除以 1e6
	    BC_input_o(:), BC_to_BT(:), BC_diss_o(:), BC_re_o(:), ...
	    BT_input_o(:), BT_diss_o(:), BT_re_o(:), ...
	    BC_input_c(:), BT_input_c(:), BT_to_BC(:), ...
	    BT_re_c(:), BT_diss_c(:), BC_re_c(:), BC_diss_c(:) ...
	    );
	
	% ----- Give English column names (original names) -----
	E.Properties.VariableNames = { ...
	    'BC_rate_S','total_volume_S', ...
	    'BC_input_o','BC_to_BT','BC_diss_o','BC_re_o', ...
	    'BT_input_o','BT_diss_o','BT_re_o', ...
	    'BC_input_c','BT_input_c','BT_to_BC','BT_re_c','BT_diss_c','BC_re_c','BC_diss_c' ...
	    };

    writetable(E, 'S.xlsx')