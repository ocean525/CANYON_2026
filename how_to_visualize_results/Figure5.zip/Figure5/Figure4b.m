figure
load('grid_W10.mat')
set(gcf,'Color','w')
set(gcf,'Units','centimeters');
set(gcf,'Position',[2 2 6 6]);



surf(XC,YC,-Depth)
shading interp
view(2)

cm='rain';
colormap(flip(cmocean(cm)))
caxis([-2500 -300])
cb = colorbar;                           % 获取 colorbar 句柄
cb.Ticks = [-2500 -2000 -1500 -1000 -500 -300]; % 精确指定刻度位置
cb.TickLabels = {'-2500','-2000','-1500','-1000','-500','-300'};  % 可选，自定义显示文字
cb.Location = 'northoutside';
title(cb,'m','color','k');
hold on
%daspect([1 1 0.1])
axis equal
xlim([280e3 400e3])
ylim([0e3 100e3])




%A= contour3(XC,YC,-Depth,[-2500:300:-350],'color',[.5 .5 .5],'linewidth',0.5)

% ticks
xticks([290e3:20e3:400e3])
xticklabels([290e3:20e3:400e3]/1000)
yticks([0e3:10e3:100e3])
yticklabels(([0e3:10e3:100e3]-50e3)/1000)



xlabel('X/km')
ylabel('Y/km')


set(gca,'Layer','top','XMinorGrid','off','YMinorTick','off','TickDir','in')
box on
% Font
set(findall(gcf,'-property','FontSize'),'FontSize',8);
set(findall(gcf,'-property','FontWeight'),'FontWeight','bold');


load('in_350m.mat')
hold on
plot(xp,yp,'k','LineWidth',1)

load('in_whole_90.mat')
hold on
plot(xp_whole,yp_whole,'k','LineWidth',1)



% here we can calculate the canyon and box volumes.
% volume_canyon=sum(Depth.*in.*DXG.*DYG,'all')
% volume_box=sum(Depth.*in_whole.*DXG.*DYG,'all')

