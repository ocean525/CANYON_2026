clear
load all_W.mat

figure
set(gcf,'Color','w')
set(gcf,'Units','centimeters');
set(gcf,'Position',[2 2 9 5]);

h1=plot(W/60, BC_rate_L*10^8, '-o', ...
    'LineWidth', 1.5, ...
    'Color', 'b', ...
    'MarkerFaceColor', 'b','MarkerSize',2)

hold on
C=plot(W(8)/60, BC_rate_L(8)*10^8, 'p', ...
    'LineWidth', 0.5, ...
    'Color','k', 'MarkerFaceColor', 'k','MarkerSize',7)



%L=[15 20 22 23 24 25.5 30 45 60];

xlim([0 0.35])
xticks(W/60)
xticklabels(compose('%.2f', W/60))


ylim([0 6])
yticks([0:6])


xlabel('W / \lambda');
ylabel(['\epsilon / 10^{-8} m^2 s^{-3}']);

xtickangle(45) 
set(gca,'Layer','top','XMinorTick','off','YMinorTick','off','TickDir','in')


%% 
% 
ax1 = gca;   % bottom axis (already plotted)

% create top axis
ax2 = axes('Position',ax1.Position,...
           'XAxisLocation','top',...
           'YAxisLocation','right',...
           'Color','none');

% choose the x positions you want (in L/λ)
xtop = W/60;

% map to real length (×60)
ax2.XLim  = ax1.XLim;
ax2.XTick = xtop;
ax2.XTickLabel = W;   % or sprintf if you want formatting
ax2.YTick = [];

xlabel(ax2,'W (km)');




set(findall(gcf,'-property','FontName'),'FontName', 'Arial');
set(findall(gcf,'-property','FontSize'),'FontSize',8);
set(findall(gcf,'-property','FontWeight'),'FontWeight','bold');


%% b
clear
load('all_W.mat')
L=W;

figure
set(gcf,'Color','w')
set(gcf,'Units','centimeters');
set(gcf,'Position',[2 2 9 5]);
hold on

r1 = [153 204 255]/255;
r2=[141 95 211]/255;
r3= [0 170 212]/255;
r4 = [255 150 150]/255;


plot(L,abs(BC_input_o), '-o', ...
    'LineWidth', 1.5, ...
    'Color', r1, ...
    'MarkerFaceColor', r1,'MarkerSize',2);
plot(L,abs(BT_to_BC), '-o', ...
    'LineWidth', 1.5, ...
    'Color', r2, ...
    'MarkerFaceColor', r2,'MarkerSize',2);
plot(L,abs(BC_input_c), '-o', ...
    'LineWidth', 1.5, ...
    'Color', r3, ...
    'MarkerFaceColor', r3,'MarkerSize',2);
plot(L,abs(BC_diss_c), '-o', ...
    'LineWidth', 1.5, ...
    'Color', r4, ...
    'MarkerFaceColor', r4,'MarkerSize',2);


W=[1 2 3 5 7 10 20];
xticks(W)


set(gca,'Layer','top','XMinorTick','off','YMinorTick','off','TickDir','in')
box on

ylabel(['Energy (MW)']);
xlim([0 0.35]*60)


set(findall(gcf,'-property','FontName'),'FontName', 'Arial');
set(findall(gcf,'-property','FontSize'),'FontSize',8);
set(findall(gcf,'-property','FontWeight'),'FontWeight','bold');
legend('BC Input (Box)','BT to BC (Canyon)','BC Input  (Canyon)','BC Diss  (Canyon)','FontSize',6,'location','best')
legend boxoff
