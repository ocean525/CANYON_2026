clear
load('all_S.mat')
S=[0.2 0.15 0.1];

figure
set(gcf,'Color','w')
set(gcf,'Units','centimeters');
set(gcf,'Position',[2 2 9 5]);

h1=plot(S, BC_rate_L*10^8, '-o', ...
    'LineWidth', 1.5, ...
    'Color', 'g', ...
    'MarkerFaceColor', 'g','MarkerSize',2)

hold on
C=plot(S(1), BC_rate_L(1)*10^8, 'p', ...
    'LineWidth', 0.5, ...
    'Color','k', 'MarkerFaceColor', 'k','MarkerSize',7)




xlim([0.07 0.23])
xticks(flip(S))



ylim([0 6])
yticks([0:6])


xlabel('S');
ylabel(['\epsilon (10^{-8} m^2 s^{-3})']);


set(gca,'Layer','top','XMinorTick','off','YMinorTick','off','TickDir','in')




set(findall(gcf,'-property','FontName'),'FontName', 'Arial');
set(findall(gcf,'-property','FontSize'),'FontSize',8);
set(findall(gcf,'-property','FontWeight'),'FontWeight','bold');


%% b
clear
load('all_S.mat')
S=[0.2 0.15 0.1];
L=S;

figure
set(gcf,'Color','w')
set(gcf,'Units','centimeters');
set(gcf,'Position',[2 2 9 5]);
hold on

r1 = [153 204 255]/255;
r2=[141 95 211]/255;
r3= [0 170 212]/255;
r4 = [255 150 150]/255;


plot(L,abs(BC_input_o), '-o', ...
    'LineWidth', 1.5, ...
    'Color', r1, ...
    'MarkerFaceColor', r1,'MarkerSize',2);
plot(L,abs(BT_to_BC), '-o', ...
    'LineWidth', 1.5, ...
    'Color', r2, ...
    'MarkerFaceColor', r2,'MarkerSize',2);
plot(L,abs(BC_input_c), '-o', ...
    'LineWidth', 1.5, ...
    'Color', r3, ...
    'MarkerFaceColor', r3,'MarkerSize',2);
plot(L,abs(BC_diss_c), '-o', ...
    'LineWidth', 1.5, ...
    'Color', r4, ...
    'MarkerFaceColor', r4,'MarkerSize',2);

plot(L,abs(BC_diss_o), '-o', ...
    'LineWidth', 1.25, ...
    'Color', [255 245 180]/255, ...
    'MarkerFaceColor',[255 245 180]/255,'MarkerSize',1.75);




xlim([0.07 0.23])
xticks(flip(S))


set(gca,'Layer','top','XMinorTick','off','YMinorTick','off','TickDir','in')
box on

ylabel(['Energy (MW)']);

set(findall(gcf,'-property','FontName'),'FontName', 'Arial');
set(findall(gcf,'-property','FontSize'),'FontSize',8);
set(findall(gcf,'-property','FontWeight'),'FontWeight','bold');
%legend('BC Input (Box)','BT to BC (Canyon)','BC Input (Canyon)','BC Diss (Canyon)','FontSize',6,'location','best')
legend('BC Input (Box)','BT to BC (Canyon)','BC Input (Canyon)','BC Diss (Canyon)','BC Diss (Out-of-Canyon)','FontSize',6,'location','best')

legend boxoff
