% a
load('Con_W10.mat')
load('grid_W10.mat')

% b
load('Con_015.mat')
load('grid_015.mat')

% c
load('Con_010.mat')
load('grid_010.mat')


%% 

rho0=999.8;

CON=sq(mean(Conv(1:48,:,:),1))*rho0;

ca=[-0.1,0.1];

var = CON;

xl=[300e3 360e3];
yl=[30e3 70e3];

figure
set(gcf,'Color','w')
set(gcf,'Units','centimeters');
set(gcf,'Position',[2 2 8.6 5.3]);

pcolor(XC,YC,var);shading interp
rwbcmap
caxis(ca)

 colorbar off

hold on
[C,h] = contour(XC,YC,-Depth,[-2500:300:-350],'-','color',[.85 .85 .85],'LineWidth',0.2);


axis equal
xlim(xl)
ylim(yl)

xticks([ xl(1):10e3: xl(end)])
xticklabels([ xl(1):10e3: xl(end)]/1000)
yticks([ yl(1):10e3:yl(end)])

yticklabels(([yl(1):10e3:yl(end)]-50e3)/1000)


set(gca,'Layer','top','XMinorGrid','off','YMinorTick','off','TickDir','in')
box on

set(findall(gcf,'-property','FontSize'),'FontSize',8);
set(findall(gcf,'-property','FontWeight'),'FontWeight','bold');
